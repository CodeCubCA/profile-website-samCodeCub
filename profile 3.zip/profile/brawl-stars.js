// Brawl Stars Game
class BrawlStars {
    constructor() {
        this.canvas = null;
        this.ctx = null;
        this.width = 600;
        this.height = 400;
        this.mapWidth = 1200;  // Map is 2x wider
        this.mapHeight = 800;  // Map is 2x taller
        this.running = false;
        this.paused = false;
        this.autoPaused = false;
        this.gameLoop = null;
        this.countdown = 0;
        this.countdownActive = false;
        this.waitingToStart = false;
        this.gameState = 'home'; // 'home', 'brawlers', 'battle', 'countdown', 'playing'
        this.selectedBrawlerForBattle = 'mortis';

        // Camera system
        this.camera = {
            x: 0,
            y: 0,
            smoothing: 0.1
        };

        // Player
        this.player = {
            x: this.mapWidth / 2,  // Start in center of map
            y: this.mapHeight / 2,
            size: 25,
            health: 100,
            maxHealth: 100,
            speed: 3,
            ammo: 3,
            maxAmmo: 3,
            reloadTime: 0,
            brawler: 'mortis',
            superCharge: 0,
            maxSuperCharge: 100,
            invulnerable: 0,
            speedBoost: 0
        };

        // Game objects
        this.enemies = [];
        this.bullets = [];
        this.gems = [];
        this.particles = [];
        this.powerUps = [];
        this.superEffects = [];
        this.damageNumbers = [];
        this.gemsCollected = 0;
        this.keys = {};

        // Brawler stats - Mortis only
        this.brawlers = {
            mortis: {
                damage: 50, range: 60, bulletSpeed: 15, spread: 1,
                super: 'bat_swarm', superDesc: 'Healing bat swarm attack'
            }
        };

        // Power-ups
        this.powerUpTypes = {
            health: { color: '#ff3366', effect: 'heal', value: 50 },
            speed: { color: '#00aaff', effect: 'speed', value: 120 },
            damage: { color: '#ff6600', effect: 'damage', value: 180 },
            shield: { color: '#aa00ff', effect: 'shield', value: 60 }
        };
    }

    start() {
        console.log('Starting Brawl Stars...');
        this.canvas = document.getElementById('brawlGame');
        console.log('Canvas found:', this.canvas);
        if (!this.canvas) {
            console.error('Canvas not found!');
            return;
        }

        this.ctx = this.canvas.getContext('2d');

        // Test draw something to make sure canvas is working
        this.ctx.fillStyle = 'lime';
        this.ctx.fillRect(0, 0, 100, 100);
        this.ctx.fillStyle = 'white';
        this.ctx.font = '20px Arial';
        this.ctx.fillText('CANVAS WORKS!', 10, 50);
        console.log('Test drawing completed');

        // Reset game state
        this.player.x = this.mapWidth / 2;  // Start in center of map
        this.player.y = this.mapHeight / 2;
        this.player.health = 100;
        this.player.ammo = 3;
        this.player.superCharge = 0;
        this.player.invulnerable = 0;
        this.player.speedBoost = 0;
        this.enemies = [];
        this.bullets = [];
        this.gems = [];
        this.particles = [];
        this.powerUps = [];
        this.superEffects = [];
        this.damageNumbers = [];
        this.gemsCollected = 0;

        // Create initial enemies, gems, and power-ups
        this.spawnEnemies();
        this.spawnGems();
        this.spawnPowerUps();

        // Event listeners
        this.setupControls();

        // Show home screen
        this.showHomeScreen();
    }

    showHomeScreen() {
        console.log('showHomeScreen called');
        this.gameState = 'home';
        this.running = false;
        this.waitingToStart = false;
        this.countdownActive = false;

        // Start drawing loop for home screen
        if (this.gameLoop) clearInterval(this.gameLoop);
        this.gameLoop = setInterval(() => this.draw(), 1000/60);
        console.log('Drawing loop started for home screen');

        this.updateStartButton();
        console.log('Showing home screen');
    }

    showBrawlersMenu() {
        this.gameState = 'brawlers';
        console.log('Showing brawlers menu');
    }

    showBattleScreen() {
        this.gameState = 'battle';
        this.player.brawler = this.selectedBrawlerForBattle;
        this.waitingToStart = true; // Allow battle to be started

        // Start drawing loop for battle screen
        if (this.gameLoop) clearInterval(this.gameLoop);
        this.gameLoop = setInterval(() => this.draw(), 1000/60);

        this.updateStartButton();
        console.log(`Preparing battle with ${this.selectedBrawlerForBattle}`);
    }

    showStartScreen() {
        this.waitingToStart = true;
        this.running = false;
        this.countdownActive = false;

        // Start drawing loop for start screen
        if (this.gameLoop) clearInterval(this.gameLoop);
        this.gameLoop = setInterval(() => this.draw(), 1000/60);

        // Update button text
        this.updateStartButton();

        console.log('Showing start screen - click Start Battle to begin!');
    }

    startBattle() {
        console.log('startBattle() called, waitingToStart:', this.waitingToStart);
        if (!this.waitingToStart) {
            console.log('Not waiting to start, exiting startBattle()');
            return;
        }

        console.log('Starting battle!');
        this.waitingToStart = false;
        this.updateStartButton();
        this.startCountdown();
    }

    updateStartButton() {
        const startBtn = document.getElementById('startBrawlBtn');
        if (startBtn) {
            if (this.gameState === 'battle') {
                startBtn.textContent = '⚔️ START BATTLE';
                startBtn.style.backgroundColor = '#00ff88';
                startBtn.style.animation = 'pulse 2s infinite';
            } else if (this.gameState === 'home') {
                startBtn.textContent = '🎮 START BATTLE';
                startBtn.style.backgroundColor = '#ff3366';
                startBtn.style.animation = 'pulse 2s infinite';
            } else {
                startBtn.textContent = '⭐ Start Brawl';
                startBtn.style.backgroundColor = '';
                startBtn.style.animation = '';
            }
        }
    }

    startCountdown() {
        console.log('Starting countdown...');
        this.countdownActive = true;
        this.countdown = 5;
        this.running = false; // Don't start game logic yet

        // Start countdown timer and drawing
        if (this.gameLoop) clearInterval(this.gameLoop);
        this.gameLoop = setInterval(() => this.updateCountdown(), 1000/60);

        // Update countdown every second
        this.countdownInterval = setInterval(() => {
            this.countdown--;
            console.log('Countdown:', this.countdown);

            if (this.countdown <= 0) {
                this.endCountdown();
            }
        }, 1000);
    }

    updateCountdown() {
        this.draw(); // Keep drawing the game scene during countdown
    }

    endCountdown() {
        console.log('Countdown finished - starting game!');

        // Clear countdown interval
        if (this.countdownInterval) {
            clearInterval(this.countdownInterval);
            this.countdownInterval = null;
        }

        // Start actual game
        this.countdownActive = false;
        this.running = true;
        this.gameState = 'playing'; // Change state to playing
        this.waitingToStart = false; // Make sure this is false

        // Start normal game loop
        if (this.gameLoop) clearInterval(this.gameLoop);
        this.gameLoop = setInterval(() => this.update(), 1000/60);

        console.log('Brawl Stars started!');
    }

    setupControls() {
        // Remove old listeners if they exist
        if (this.boundKeyDown) {
            document.removeEventListener('keydown', this.boundKeyDown);
        }
        if (this.boundKeyUp) {
            document.removeEventListener('keyup', this.boundKeyUp);
        }
        if (this.boundShoot && this.canvas) {
            this.canvas.removeEventListener('click', this.boundShoot);
        }
        if (this.boundSuper && this.canvas) {
            this.canvas.removeEventListener('mousedown', this.boundSuper);
        }

        // Add new listeners
        this.boundKeyDown = (e) => {
            if (e.code === 'Space') {
                e.preventDefault();
                this.togglePause();
            } else {
                this.keys[e.code] = true;
            }
        };
        this.boundKeyUp = (e) => this.keys[e.code] = false;
        this.boundShoot = (e) => this.handleClick(e);

        document.addEventListener('keydown', this.boundKeyDown);
        document.addEventListener('keyup', this.boundKeyUp);
        this.canvas.addEventListener('click', this.boundShoot);

        // Super ability on right click
        this.boundSuper = (e) => {
            if (e.button === 2) { // Right click
                e.preventDefault();
                this.useSuper();
            }
        };
        this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
        this.canvas.addEventListener('mousedown', this.boundSuper);

        // Add visibility change listeners for auto-pause
        this.boundVisibilityChange = () => this.handleVisibilityChange();
        this.boundBeforeUnload = () => this.handleBeforeUnload();

        document.addEventListener('visibilitychange', this.boundVisibilityChange);
        window.addEventListener('beforeunload', this.boundBeforeUnload);
        window.addEventListener('blur', this.boundVisibilityChange);
        window.addEventListener('focus', this.boundVisibilityChange);
    }

    spawnEnemies() {
        const enemyTypes = ['rusher', 'sniper', 'tank'];
        for (let i = 0; i < 6; i++) { // More enemies for larger map
            const type = enemyTypes[Math.floor(Math.random() * enemyTypes.length)];
            let enemy = {
                x: Math.random() * this.mapWidth,
                y: Math.random() * this.mapHeight,
                type: type,
                shootTimer: 0,
                moveTimer: 0
            };

            // Type-specific stats
            switch(type) {
                case 'rusher':
                    enemy = {...enemy, size: 18, health: 60, maxHealth: 60, speed: 2.5, damage: 20, color: '#ff6600'};
                    break;
                case 'sniper':
                    enemy = {...enemy, size: 16, health: 50, maxHealth: 50, speed: 1, damage: 35, color: '#9900ff'};
                    break;
                case 'tank':
                    enemy = {...enemy, size: 28, health: 120, maxHealth: 120, speed: 1, damage: 30, color: '#666666'};
                    break;
            }
            this.enemies.push(enemy);
        }
    }

    spawnGems() {
        for (let i = 0; i < 8; i++) { // More gems for larger map
            this.gems.push({
                x: Math.random() * this.mapWidth,
                y: Math.random() * this.mapHeight,
                size: 15,
                bounce: Math.random() * Math.PI * 2,
                collected: false
            });
        }
    }

    spawnPowerUps() {
        const types = Object.keys(this.powerUpTypes);
        for (let i = 0; i < 5; i++) { // More power-ups for larger map
            const type = types[Math.floor(Math.random() * types.length)];
            this.powerUps.push({
                x: Math.random() * this.mapWidth,
                y: Math.random() * this.mapHeight,
                type: type,
                size: 20,
                bounce: Math.random() * Math.PI * 2,
                collected: false,
                respawnTimer: 0
            });
        }
    }

    shoot(event) {
        if (!this.running || this.paused || this.countdownActive || this.player.ammo <= 0) return;

        const rect = this.canvas.getBoundingClientRect();
        const mouseX = event.clientX - rect.left + this.camera.x;
        const mouseY = event.clientY - rect.top + this.camera.y;

        const angle = Math.atan2(mouseY - this.player.y, mouseX - this.player.x);
        const brawler = this.brawlers[this.player.brawler];

        // Create bullets based on brawler type
        if (this.player.brawler === 'nani') {
            // Nani - 3 orb projectiles
            for (let i = 0; i < 3; i++) {
                this.bullets.push({
                    x: this.player.x,
                    y: this.player.y,
                    vx: Math.cos(angle) * brawler.bulletSpeed,
                    vy: Math.sin(angle) * brawler.bulletSpeed,
                    damage: brawler.damage,
                    range: brawler.range,
                    traveled: 0,
                    owner: 'player',
                    type: 'nani_orb',
                    delay: i * 5 // Slight delay between orbs
                });
            }
        } else if (this.player.brawler === 'hank') {
            // Hank - Single bubble that bounces
            this.bullets.push({
                x: this.player.x,
                y: this.player.y,
                vx: Math.cos(angle) * brawler.bulletSpeed,
                vy: Math.sin(angle) * brawler.bulletSpeed,
                damage: brawler.damage,
                range: brawler.range,
                traveled: 0,
                owner: 'player',
                type: 'hank_bubble',
                bounces: 2 // Can bounce 2 times
            });
        } else if (this.player.brawler === 'mortis') {
            // Mortis - Dash attack (short range, high damage)
            const dashDistance = 80;
            const targetX = this.player.x + Math.cos(angle) * dashDistance;
            const targetY = this.player.y + Math.sin(angle) * dashDistance;

            // Move player towards target (dash effect)
            this.player.x = Math.max(15, Math.min(this.mapWidth - 15, targetX));
            this.player.y = Math.max(15, Math.min(this.mapHeight - 15, targetY));

            // Create area damage around new position
            this.bullets.push({
                x: this.player.x,
                y: this.player.y,
                vx: 0,
                vy: 0,
                damage: brawler.damage,
                range: 50, // Small area around mortis
                traveled: 0,
                owner: 'player',
                type: 'mortis_dash',
                life: 10 // Short duration
            });
        } else {
            // Default bullet pattern for other brawlers
            for (let i = 0; i < brawler.spread; i++) {
                const spreadAngle = angle + (i - brawler.spread/2 + 0.5) * 0.3;

                this.bullets.push({
                    x: this.player.x,
                    y: this.player.y,
                    vx: Math.cos(spreadAngle) * brawler.bulletSpeed,
                    vy: Math.sin(spreadAngle) * brawler.bulletSpeed,
                    damage: brawler.damage,
                    range: brawler.range,
                    traveled: 0,
                    owner: 'player'
                });
            }
        }

        this.player.ammo--;
        this.createMuzzleFlash(this.player.x, this.player.y, angle);
        console.log('Shot fired! Bullets created:', brawler.spread);
    }

    handleClick(event) {
        const rect = this.canvas.getBoundingClientRect();
        const clickX = event.clientX - rect.left;
        const clickY = event.clientY - rect.top;

        console.log(`Click at (${clickX}, ${clickY}) in state: ${this.gameState}`);

        if (this.gameState === 'home') {
            this.handleHomeClick(clickX, clickY);
        } else if (this.gameState === 'brawlers') {
            this.handleBrawlersClick(clickX, clickY);
        } else if (this.gameState === 'battle') {
            this.handleBattleClick(clickX, clickY);
        } else if (this.running && !this.paused && !this.countdownActive) {
            // Normal shooting during gameplay
            this.shoot(event);
        }
    }

    handleHomeClick(x, y) {
        console.log('Handling home click at:', x, y);
        console.log('Available buttons:', this.currentButtonAreas);

        if (!this.currentButtonAreas) return;

        for (let button of this.currentButtonAreas) {
            console.log(`Checking button "${button.action}" at (${button.x}, ${button.y}) size ${button.width}x${button.height}`);

            if (x >= button.x && x <= button.x + button.width &&
                y >= button.y && y <= button.y + button.height) {

                console.log(`Clicked button: ${button.action}`);

                if (button.action === '🎮 START BATTLE') {
                    this.showBattleScreen();
                }
                break;
            }
        }
    }

    handleBrawlersClick(x, y) {
        console.log('Handling brawlers click at:', x, y);

        // Check brawler cards
        if (this.currentBrawlerAreas) {
            for (let card of this.currentBrawlerAreas) {
                if (x >= card.x && x <= card.x + card.width &&
                    y >= card.y && y <= card.y + card.height) {
                    this.selectedBrawlerForBattle = card.brawler;
                    console.log(`Selected ${card.brawler} for battle!`);
                    break;
                }
            }
        }

        // Check back button
        if (this.currentButtonAreas) {
            for (let button of this.currentButtonAreas) {
                if (x >= button.x && x <= button.x + button.width &&
                    y >= button.y && y <= button.y + button.height) {

                    if (button.action === '← BACK') {
                        console.log('Clicked BACK button');
                        this.showHomeScreen();
                    }
                    break;
                }
            }
        }
    }

    handleBattleClick(x, y) {
        // Battle screen doesn't have clickable elements
        // Clicking anywhere should do nothing
    }

    useSuper() {
        if (!this.running || this.paused || this.countdownActive || this.player.superCharge < this.player.maxSuperCharge) return;

        this.player.superCharge = 0;
        const brawler = this.brawlers[this.player.brawler];

        switch(brawler.super) {
            case 'clay_pigeons':
                // Shelly - Wide shotgun blast
                for (let i = 0; i < 5; i++) {
                    const angle = (i - 2) * 0.5;
                    for (let j = 0; j < 3; j++) {
                        this.bullets.push({
                            x: this.player.x,
                            y: this.player.y,
                            vx: Math.cos(angle) * 10,
                            vy: Math.sin(angle) * 10,
                            damage: 40,
                            range: 150,
                            traveled: 0,
                            owner: 'player',
                            super: true
                        });
                    }
                }
                break;

            case 'bullet_train':
                // Colt - Piercing line of bullets
                const angle = Math.atan2(this.keys['mouseY'] - this.player.y, this.keys['mouseX'] - this.player.x);
                for (let i = 0; i < 6; i++) {
                    setTimeout(() => {
                        this.bullets.push({
                            x: this.player.x,
                            y: this.player.y,
                            vx: Math.cos(angle) * 15,
                            vy: Math.sin(angle) * 15,
                            damage: 50,
                            range: 300,
                            traveled: 0,
                            owner: 'player',
                            piercing: true,
                            super: true
                        });
                    }, i * 100);
                }
                break;

            case 'bulldozer':
                // Bull - Charge attack
                this.player.speedBoost = 180; // 3 seconds
                this.player.invulnerable = 60; // 1 second
                break;

            case 'big_barrel':
                // Dynamike - Explosive barrel
                this.superEffects.push({
                    x: this.player.x + 50,
                    y: this.player.y,
                    type: 'barrel',
                    timer: 120, // 2 seconds to explode
                    size: 30
                });
                break;

            case 'peep':
                // Nani - Remote controlled Peep robot
                this.superEffects.push({
                    x: this.player.x + 100,
                    y: this.player.y,
                    type: 'peep',
                    timer: 300, // 5 seconds duration
                    size: 25,
                    vx: 3,
                    vy: 0
                });
                break;

            case 'bubble_wrap':
                // Hank - Multiple bouncing bubbles
                for (let i = 0; i < 5; i++) {
                    const bubbleAngle = (i - 2) * 0.8;
                    this.bullets.push({
                        x: this.player.x,
                        y: this.player.y,
                        vx: Math.cos(bubbleAngle) * 8,
                        vy: Math.sin(bubbleAngle) * 8,
                        damage: 60,
                        range: 200,
                        traveled: 0,
                        owner: 'player',
                        type: 'super_bubble',
                        bounces: 3,
                        super: true
                    });
                }
                break;

            case 'bat_swarm':
                // Mortis - Healing bat swarm
                for (let i = 0; i < 8; i++) {
                    const batAngle = (Math.PI * 2 / 8) * i;
                    this.bullets.push({
                        x: this.player.x,
                        y: this.player.y,
                        vx: Math.cos(batAngle) * 6,
                        vy: Math.sin(batAngle) * 6,
                        damage: 40,
                        range: 120,
                        traveled: 0,
                        owner: 'player',
                        type: 'bat',
                        super: true,
                        healing: true
                    });
                }
                // Heal player
                this.player.health = Math.min(this.player.maxHealth, this.player.health + 50);
                break;
        }

        this.createSuperEffect(this.player.x, this.player.y);
    }

    togglePause() {
        if (!this.running && !this.countdownActive) return;

        this.paused = !this.paused;
        console.log(this.paused ? 'Game paused' : 'Game resumed');
    }

    handleVisibilityChange() {
        if (!this.running) return;

        if (document.hidden || document.visibilityState === 'hidden') {
            // Page is hidden (tab switched, minimized, etc.)
            if (!this.paused) {
                this.paused = true;
                this.autoPaused = true; // Track that this was an auto-pause
                console.log('Game auto-paused (tab hidden)');
            }
        } else {
            // Page is visible again
            if (this.autoPaused && this.paused) {
                this.paused = false;
                this.autoPaused = false;
                console.log('Game auto-resumed (tab visible)');
            }
        }
    }

    handleBeforeUnload() {
        // Pause game before page unloads (refresh, close, navigate away)
        if (this.running && !this.paused) {
            this.paused = true;
            console.log('Game paused (page unloading)');
        }
    }

    update() {
        if (!this.running || this.paused) return;

        this.updatePlayer();
        this.updateCamera();
        this.updateEnemies();
        this.updateBullets();
        this.updateGems();
        this.updatePowerUps();
        this.updateSuperEffects();
        this.updateParticles();
        this.updateDamageNumbers();
        this.updateUI();
        this.draw();

        // Check win condition
        if (this.gemsCollected >= 10) {
            this.win();
        }
    }

    updatePlayer() {
        // Update buffs
        if (this.player.invulnerable > 0) this.player.invulnerable--;
        if (this.player.speedBoost > 0) this.player.speedBoost--;

        // Movement with speed boost
        const speed = this.player.speedBoost > 0 ? this.player.speed * 2 : this.player.speed;
        if (this.keys['KeyW'] || this.keys['ArrowUp']) this.player.y -= speed;
        if (this.keys['KeyS'] || this.keys['ArrowDown']) this.player.y += speed;
        if (this.keys['KeyA'] || this.keys['ArrowLeft']) this.player.x -= speed;
        if (this.keys['KeyD'] || this.keys['ArrowRight']) this.player.x += speed;

        // Keep player in map bounds
        this.player.x = Math.max(15, Math.min(this.mapWidth - 15, this.player.x));
        this.player.y = Math.max(15, Math.min(this.mapHeight - 15, this.player.y));

        // Reload ammo
        if (this.player.ammo < this.player.maxAmmo) {
            this.player.reloadTime++;
            if (this.player.reloadTime >= 120) { // 2 seconds at 60fps
                this.player.ammo++;
                this.player.reloadTime = 0;
            }
        }
    }

    updateCamera() {
        // Camera follows player smoothly
        const targetX = this.player.x - this.width / 2;
        const targetY = this.player.y - this.height / 2;

        // Smooth camera movement
        this.camera.x += (targetX - this.camera.x) * this.camera.smoothing;
        this.camera.y += (targetY - this.camera.y) * this.camera.smoothing;

        // Keep camera within map bounds
        this.camera.x = Math.max(0, Math.min(this.mapWidth - this.width, this.camera.x));
        this.camera.y = Math.max(0, Math.min(this.mapHeight - this.height, this.camera.y));
    }

    updateEnemies() {
        for (let enemy of this.enemies) {
            if (enemy.health <= 0) continue;

            // Move towards player
            const dx = this.player.x - enemy.x;
            const dy = this.player.y - enemy.y;
            const dist = Math.sqrt(dx * dx + dy * dy);

            if (dist > 30) {
                enemy.x += (dx / dist) * enemy.speed;
                enemy.y += (dy / dist) * enemy.speed;
            }

            // Shoot at player
            enemy.shootTimer++;
            if (enemy.shootTimer >= 180 && dist < 200) { // 3 seconds
                const angle = Math.atan2(dy, dx);
                this.bullets.push({
                    x: enemy.x,
                    y: enemy.y,
                    vx: Math.cos(angle) * 6,
                    vy: Math.sin(angle) * 6,
                    damage: 15,
                    range: 150,
                    traveled: 0,
                    owner: 'enemy'
                });
                enemy.shootTimer = 0;
                this.createMuzzleFlash(enemy.x, enemy.y, angle);
            }
        }
    }

    updateBullets() {
        for (let i = this.bullets.length - 1; i >= 0; i--) {
            const bullet = this.bullets[i];

            // Handle special bullet types
            if (bullet.type === 'mortis_dash') {
                bullet.life--;
                if (bullet.life <= 0) {
                    this.bullets.splice(i, 1);
                    continue;
                }
            } else if (bullet.type === 'hank_bubble' || bullet.type === 'super_bubble') {
                // Handle bouncing for Hank's bubbles
                if (bullet.x <= 10 || bullet.x >= this.mapWidth - 10) {
                    bullet.vx = -bullet.vx;
                    bullet.bounces--;
                }
                if (bullet.y <= 10 || bullet.y >= this.mapHeight - 10) {
                    bullet.vy = -bullet.vy;
                    bullet.bounces--;
                }
                if (bullet.bounces < 0) {
                    this.bullets.splice(i, 1);
                    continue;
                }
                bullet.x += bullet.vx;
                bullet.y += bullet.vy;
            } else {
                // Normal bullet movement
                bullet.x += bullet.vx;
                bullet.y += bullet.vy;
            }

            bullet.traveled += Math.sqrt(bullet.vx * bullet.vx + bullet.vy * bullet.vy);

            // Remove if out of range or map bounds (except bouncing bullets)
            if (bullet.traveled > bullet.range ||
                (!bullet.bounces && (bullet.x < 0 || bullet.x > this.mapWidth || bullet.y < 0 || bullet.y > this.mapHeight))) {
                this.bullets.splice(i, 1);
                continue;
            }

            // Check collisions
            if (bullet.owner === 'player') {
                // Hit enemies
                for (let j = 0; j < this.enemies.length; j++) {
                    const enemy = this.enemies[j];
                    if (enemy.health > 0 && this.checkCollision(bullet, enemy)) {
                        console.log(`Hit! ${bullet.type} Enemy health: ${enemy.health} -> ${enemy.health - bullet.damage}`);
                        enemy.health -= bullet.damage;
                        this.player.superCharge = Math.min(this.player.maxSuperCharge, this.player.superCharge + 15);
                        this.createHitEffect(bullet.x, bullet.y);
                        this.createDamageNumber(bullet.x, bullet.y, bullet.damage, '#ffaa00');

                        // Remove enemy if dead
                        if (enemy.health <= 0) {
                            console.log('Enemy killed!');
                        }

                        if (!bullet.piercing) {
                            this.bullets.splice(i, 1);
                            break;
                        }
                    }
                }
            } else {
                // Hit player (unless invulnerable)
                if (this.checkCollision(bullet, this.player) && this.player.invulnerable <= 0) {
                    this.player.health -= bullet.damage;
                    this.createHitEffect(bullet.x, bullet.y);
                    this.createDamageNumber(bullet.x, bullet.y, bullet.damage, '#ff3366');
                    this.bullets.splice(i, 1);

                    if (this.player.health <= 0) {
                        this.gameOver();
                    }
                }
            }
        }
    }

    updateGems() {
        for (let gem of this.gems) {
            if (gem.collected) continue;

            gem.bounce += 0.1;

            // Check collection
            if (this.checkCollision(gem, this.player)) {
                gem.collected = true;
                this.gemsCollected++;
                this.createGemEffect(gem.x, gem.y);
            }
        }
    }

    updatePowerUps() {
        for (let powerUp of this.powerUps) {
            if (powerUp.collected) {
                powerUp.respawnTimer++;
                if (powerUp.respawnTimer >= 600) { // 10 seconds
                    powerUp.collected = false;
                    powerUp.respawnTimer = 0;
                    powerUp.x = Math.random() * this.mapWidth;
                    powerUp.y = Math.random() * this.mapHeight;
                }
                continue;
            }

            powerUp.bounce += 0.08;

            // Check collection
            if (this.checkCollision(powerUp, this.player)) {
                powerUp.collected = true;
                this.applyPowerUp(powerUp.type);
                this.createPowerUpEffect(powerUp.x, powerUp.y, powerUp.type);
            }
        }
    }

    updateSuperEffects() {
        for (let i = this.superEffects.length - 1; i >= 0; i--) {
            const effect = this.superEffects[i];
            effect.timer--;

            if (effect.type === 'barrel' && effect.timer <= 0) {
                // Dynamike barrel explosion
                for (let enemy of this.enemies) {
                    const dx = enemy.x - effect.x;
                    const dy = enemy.y - effect.y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    if (dist < 80) {
                        enemy.health -= 80;
                        this.createExplosionEffect(effect.x, effect.y);
                    }
                }
                this.superEffects.splice(i, 1);
            } else if (effect.type === 'peep') {
                // Nani's Peep robot movement
                effect.x += effect.vx;
                effect.y += effect.vy;

                // Keep Peep in bounds
                if (effect.x <= 20 || effect.x >= this.mapWidth - 20) {
                    effect.vx = -effect.vx;
                }
                if (effect.y <= 20 || effect.y >= this.mapHeight - 20) {
                    effect.vy = -effect.vy;
                }

                // Peep shoots at enemies
                if (effect.timer % 30 === 0) { // Shoot every 0.5 seconds
                    for (let enemy of this.enemies) {
                        if (enemy.health > 0) {
                            const dx = enemy.x - effect.x;
                            const dy = enemy.y - effect.y;
                            const dist = Math.sqrt(dx * dx + dy * dy);
                            if (dist < 150) {
                                const angle = Math.atan2(dy, dx);
                                this.bullets.push({
                                    x: effect.x,
                                    y: effect.y,
                                    vx: Math.cos(angle) * 8,
                                    vy: Math.sin(angle) * 8,
                                    damage: 70,
                                    range: 150,
                                    traveled: 0,
                                    owner: 'player',
                                    type: 'peep_bullet',
                                    super: true
                                });
                                break;
                            }
                        }
                    }
                }

                if (effect.timer <= 0) {
                    this.superEffects.splice(i, 1);
                }
            }
        }
    }

    updateDamageNumbers() {
        for (let i = this.damageNumbers.length - 1; i >= 0; i--) {
            const dmg = this.damageNumbers[i];
            dmg.y -= 2;
            dmg.life--;
            dmg.opacity = dmg.life / 60;

            if (dmg.life <= 0) {
                this.damageNumbers.splice(i, 1);
            }
        }
    }

    updateParticles() {
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const particle = this.particles[i];
            particle.x += particle.vx;
            particle.y += particle.vy;
            particle.life--;
            particle.vx *= 0.98;
            particle.vy *= 0.98;

            if (particle.life <= 0) {
                this.particles.splice(i, 1);
            }
        }
    }

    updateUI() {
        // Update health bar
        const healthFill = document.querySelector('.health-fill');
        const healthText = document.querySelector('.health-text');
        const healthPercent = (this.player.health / this.player.maxHealth) * 100;

        if (healthFill) healthFill.style.width = healthPercent + '%';
        if (healthText) healthText.textContent = Math.max(0, Math.round(healthPercent)) + '%';

        // Update ammo
        const ammoSlots = document.querySelectorAll('.ammo-slot');
        ammoSlots.forEach((slot, index) => {
            slot.classList.toggle('filled', index < this.player.ammo);
        });

        // Update gems
        const gemsCounter = document.querySelector('.gems-counter');
        if (gemsCounter) gemsCounter.textContent = `💎 ${this.gemsCollected}`;

        // Update super bar
        const superFill = document.querySelector('.super-fill');
        const superText = document.querySelector('.super-text');
        const superPercent = (this.player.superCharge / this.player.maxSuperCharge) * 100;

        if (superFill) {
            superFill.style.width = superPercent + '%';
            if (superPercent >= 100) {
                superFill.style.boxShadow = '0 0 20px rgba(255, 170, 0, 0.8)';
            } else {
                superFill.style.boxShadow = 'none';
            }
        }

        if (superText) {
            if (superPercent >= 100) {
                superText.textContent = 'READY!';
                superText.style.color = '#ffaa00';
            } else {
                superText.textContent = 'SUPER';
                superText.style.color = 'white';
            }
        }
    }

    checkCollision(obj1, obj2) {
        const dx = obj1.x - obj2.x;
        const dy = obj1.y - obj2.y;
        const distance = Math.sqrt(dx * dx + dy * dy);

        // For mortis_dash, use the range as the collision radius
        if (obj1.type === 'mortis_dash') {
            return distance < obj1.range;
        }

        // For bullets, use a slightly larger collision radius
        let obj1Size = obj1.size || (obj1.damage ? 6 : obj1.size); // Bullets don't have size, so give them one
        let obj2Size = obj2.size || 20;

        return distance < (obj1Size + obj2Size) / 2;
    }

    createMuzzleFlash(x, y, angle) {
        for (let i = 0; i < 5; i++) {
            this.particles.push({
                x: x + Math.cos(angle) * 20,
                y: y + Math.sin(angle) * 20,
                vx: Math.cos(angle + (Math.random() - 0.5) * 0.5) * 8,
                vy: Math.sin(angle + (Math.random() - 0.5) * 0.5) * 8,
                life: 10,
                color: '#ffaa00',
                size: 3
            });
        }
    }

    createHitEffect(x, y) {
        for (let i = 0; i < 8; i++) {
            this.particles.push({
                x: x,
                y: y,
                vx: (Math.random() - 0.5) * 10,
                vy: (Math.random() - 0.5) * 10,
                life: 20,
                color: '#ff3366',
                size: 4
            });
        }
    }

    createGemEffect(x, y) {
        for (let i = 0; i < 12; i++) {
            this.particles.push({
                x: x,
                y: y,
                vx: (Math.random() - 0.5) * 12,
                vy: (Math.random() - 0.5) * 12,
                life: 30,
                color: '#00ff88',
                size: 5
            });
        }
    }

    applyPowerUp(type) {
        const powerUp = this.powerUpTypes[type];

        switch(powerUp.effect) {
            case 'heal':
                this.player.health = Math.min(this.player.maxHealth, this.player.health + powerUp.value);
                break;
            case 'speed':
                this.player.speedBoost = powerUp.value;
                break;
            case 'damage':
                // Damage boost handled in bullet creation
                this.player.damageBoost = powerUp.value;
                break;
            case 'shield':
                this.player.invulnerable = powerUp.value;
                break;
        }
    }

    createPowerUpEffect(x, y, type) {
        const color = this.powerUpTypes[type].color;
        for (let i = 0; i < 15; i++) {
            this.particles.push({
                x: x,
                y: y,
                vx: (Math.random() - 0.5) * 15,
                vy: (Math.random() - 0.5) * 15,
                life: 40,
                color: color,
                size: 6
            });
        }
    }

    createSuperEffect(x, y) {
        for (let i = 0; i < 20; i++) {
            this.particles.push({
                x: x,
                y: y,
                vx: (Math.random() - 0.5) * 20,
                vy: (Math.random() - 0.5) * 20,
                life: 50,
                color: '#ffaa00',
                size: 8
            });
        }
    }

    createExplosionEffect(x, y) {
        for (let i = 0; i < 25; i++) {
            this.particles.push({
                x: x,
                y: y,
                vx: (Math.random() - 0.5) * 25,
                vy: (Math.random() - 0.5) * 25,
                life: 60,
                color: '#ff6600',
                size: 10
            });
        }
    }

    createDamageNumber(x, y, damage, color) {
        this.damageNumbers.push({
            x: x + (Math.random() - 0.5) * 20,
            y: y - 10,
            damage: damage,
            color: color,
            life: 60,
            opacity: 1
        });
    }

    draw() {
        console.log('Drawing, gameState:', this.gameState);
        // Save context for camera transformation
        this.ctx.save();

        // Apply camera transformation
        this.ctx.translate(-this.camera.x, -this.camera.y);

        // Clear canvas with arena background (larger map)
        const gradient = this.ctx.createRadialGradient(this.mapWidth/2, this.mapHeight/2, 0, this.mapWidth/2, this.mapHeight/2, this.mapWidth/2);
        gradient.addColorStop(0, '#2a4d3a');
        gradient.addColorStop(1, '#1a2d2a');
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.mapWidth, this.mapHeight);

        // Draw map boundaries
        this.ctx.strokeStyle = '#ffaa00';
        this.ctx.lineWidth = 4;
        this.ctx.strokeRect(10, 10, this.mapWidth - 20, this.mapHeight - 20);

        // Draw grid pattern for map
        this.ctx.strokeStyle = 'rgba(255, 170, 0, 0.1)';
        this.ctx.lineWidth = 1;
        for (let x = 0; x < this.mapWidth; x += 50) {
            this.ctx.beginPath();
            this.ctx.moveTo(x, 0);
            this.ctx.lineTo(x, this.mapHeight);
            this.ctx.stroke();
        }
        for (let y = 0; y < this.mapHeight; y += 50) {
            this.ctx.beginPath();
            this.ctx.moveTo(0, y);
            this.ctx.lineTo(this.mapWidth, y);
            this.ctx.stroke();
        }

        // Draw gems
        for (let gem of this.gems) {
            if (!gem.collected) {
                this.ctx.save();
                this.ctx.translate(gem.x, gem.y);
                this.ctx.scale(1 + Math.sin(gem.bounce) * 0.2, 1 + Math.sin(gem.bounce) * 0.2);
                this.ctx.fillStyle = '#00ff88';
                this.ctx.shadowBlur = 10;
                this.ctx.shadowColor = '#00ff88';
                this.ctx.fillRect(-gem.size/2, -gem.size/2, gem.size, gem.size);
                this.ctx.restore();
            }
        }

        // Draw power-ups
        for (let powerUp of this.powerUps) {
            if (!powerUp.collected) {
                this.ctx.save();
                this.ctx.translate(powerUp.x, powerUp.y);
                this.ctx.scale(1 + Math.sin(powerUp.bounce) * 0.3, 1 + Math.sin(powerUp.bounce) * 0.3);
                this.ctx.fillStyle = this.powerUpTypes[powerUp.type].color;
                this.ctx.shadowBlur = 12;
                this.ctx.shadowColor = this.powerUpTypes[powerUp.type].color;
                this.ctx.fillRect(-powerUp.size/2, -powerUp.size/2, powerUp.size, powerUp.size);
                this.ctx.restore();
            }
        }

        // Draw super effects
        for (let effect of this.superEffects) {
            if (effect.type === 'barrel') {
                this.ctx.fillStyle = '#8B4513';
                this.ctx.shadowBlur = 20;
                this.ctx.shadowColor = '#ff6600';
                this.ctx.fillRect(effect.x - effect.size/2, effect.y - effect.size/2, effect.size, effect.size);

                // Blinking effect when about to explode
                if (effect.timer < 30 && Math.floor(effect.timer / 5) % 2) {
                    this.ctx.fillStyle = '#ff3366';
                    this.ctx.fillRect(effect.x - effect.size/2, effect.y - effect.size/2, effect.size, effect.size);
                }
            } else if (effect.type === 'peep') {
                // Draw Nani's Peep robot
                this.ctx.fillStyle = '#00ccff';
                this.ctx.shadowBlur = 15;
                this.ctx.shadowColor = '#00ccff';
                this.ctx.fillRect(effect.x - effect.size/2, effect.y - effect.size/2, effect.size, effect.size);

                // Draw Peep's eye
                this.ctx.fillStyle = '#ffffff';
                this.ctx.shadowBlur = 0;
                this.ctx.fillRect(effect.x - 4, effect.y - 4, 8, 8);
            }
        }

        // Draw player with special effects
        this.ctx.fillStyle = this.player.invulnerable > 0 ? '#ffff00' : '#00aaff';
        if (this.player.speedBoost > 0) {
            this.ctx.shadowBlur = 25;
            this.ctx.shadowColor = '#00ffff';
        } else {
            this.ctx.shadowBlur = 15;
            this.ctx.shadowColor = '#00aaff';
        }

        // Flashing effect when invulnerable
        if (this.player.invulnerable <= 0 || Math.floor(this.player.invulnerable / 5) % 2) {
            this.ctx.fillRect(this.player.x - this.player.size/2, this.player.y - this.player.size/2, this.player.size, this.player.size);
        }

        // Draw enemies
        for (let enemy of this.enemies) {
            if (enemy.health > 0) {
                this.ctx.fillStyle = enemy.color;
                this.ctx.shadowBlur = 10;
                this.ctx.shadowColor = enemy.color;
                this.ctx.fillRect(enemy.x - enemy.size/2, enemy.y - enemy.size/2, enemy.size, enemy.size);

                // Health bar
                this.ctx.fillStyle = '#ff3366';
                this.ctx.fillRect(enemy.x - 15, enemy.y - 20, 30 * (enemy.health / enemy.maxHealth), 4);
            }
        }

        // Draw bullets with enhanced effects
        this.ctx.shadowBlur = 5;
        for (let bullet of this.bullets) {
            if (bullet.type === 'nani_orb') {
                // Nani's orb projectiles
                this.ctx.fillStyle = '#ff00ff';
                this.ctx.shadowColor = '#ff00ff';
                this.ctx.shadowBlur = 12;
                this.ctx.beginPath();
                this.ctx.arc(bullet.x, bullet.y, 6, 0, Math.PI * 2);
                this.ctx.fill();
            } else if (bullet.type === 'hank_bubble' || bullet.type === 'super_bubble') {
                // Hank's bubble attacks
                this.ctx.fillStyle = 'rgba(0, 255, 255, 0.6)';
                this.ctx.shadowColor = '#00ffff';
                this.ctx.shadowBlur = 10;
                this.ctx.beginPath();
                this.ctx.arc(bullet.x, bullet.y, 8, 0, Math.PI * 2);
                this.ctx.fill();
                // Bubble outline
                this.ctx.strokeStyle = '#00ffff';
                this.ctx.lineWidth = 2;
                this.ctx.stroke();
            } else if (bullet.type === 'mortis_dash') {
                // Mortis dash area effect
                this.ctx.fillStyle = 'rgba(128, 0, 128, 0.5)';
                this.ctx.shadowColor = '#800080';
                this.ctx.shadowBlur = 20;
                this.ctx.beginPath();
                this.ctx.arc(bullet.x, bullet.y, 30, 0, Math.PI * 2);
                this.ctx.fill();
            } else if (bullet.type === 'bat') {
                // Mortis bat swarm
                this.ctx.fillStyle = '#4a0a4a';
                this.ctx.shadowColor = '#800080';
                this.ctx.shadowBlur = 8;
                this.ctx.beginPath();
                this.ctx.arc(bullet.x, bullet.y, 4, 0, Math.PI * 2);
                this.ctx.fill();
            } else if (bullet.super) {
                // Other super bullets
                this.ctx.fillStyle = '#ffaa00';
                this.ctx.shadowColor = '#ffaa00';
                this.ctx.shadowBlur = 15;
                this.ctx.beginPath();
                this.ctx.arc(bullet.x, bullet.y, 5, 0, Math.PI * 2);
                this.ctx.fill();
            } else {
                // Default bullets
                this.ctx.fillStyle = bullet.owner === 'player' ? '#ffff00' : '#ff6600';
                this.ctx.shadowColor = bullet.owner === 'player' ? '#ffff00' : '#ff6600';
                this.ctx.shadowBlur = 5;
                this.ctx.beginPath();
                this.ctx.arc(bullet.x, bullet.y, 3, 0, Math.PI * 2);
                this.ctx.fill();
            }
        }

        // Draw particles
        for (let particle of this.particles) {
            const opacity = particle.life / 30;
            this.ctx.globalAlpha = opacity;
            this.ctx.fillStyle = particle.color;
            this.ctx.shadowColor = particle.color;
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
            this.ctx.fill();
        }

        this.ctx.globalAlpha = 1;
        this.ctx.shadowBlur = 0;

        // Draw damage numbers
        for (let dmg of this.damageNumbers) {
            this.ctx.globalAlpha = dmg.opacity;
            this.ctx.fillStyle = dmg.color;
            this.ctx.font = 'bold 16px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText(dmg.damage, dmg.x, dmg.y);
        }

        this.ctx.globalAlpha = 1;

        // Restore context (end camera transformation)
        this.ctx.restore();

        // Draw UI elements (not affected by camera)
        this.drawUI();

        // Draw different game states
        if (this.gameState === 'home') {
            this.drawHomeScreen();
        } else if (this.gameState === 'brawlers') {
            this.drawBrawlersMenu();
        } else if (this.gameState === 'battle' && this.waitingToStart) {
            this.drawBattleScreen();
        }
        // Draw start screen
        else if (this.waitingToStart) {
            this.ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
            this.ctx.fillRect(0, 0, this.width, this.height);

            this.ctx.fillStyle = '#ffaa00';
            this.ctx.font = 'bold 60px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.shadowBlur = 20;
            this.ctx.shadowColor = '#ffaa00';
            this.ctx.fillText('BRAWL STARS', this.width / 2, this.height / 2 - 60);

            this.ctx.fillStyle = '#ffffff';
            this.ctx.font = '24px Arial';
            this.ctx.shadowBlur = 0;
            this.ctx.fillText('Choose your brawler below, then click START BATTLE!', this.width / 2, this.height / 2 - 10);

            this.ctx.fillStyle = '#00ff88';
            this.ctx.font = 'bold 32px Arial';
            this.ctx.shadowBlur = 15;
            this.ctx.shadowColor = '#00ff88';
            this.ctx.fillText('🎮 READY TO FIGHT? 🎮', this.width / 2, this.height / 2 + 40);

            this.ctx.textAlign = 'left';
            this.ctx.shadowBlur = 0;
        }
        // Draw countdown screen
        else if (this.countdownActive) {
            this.ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
            this.ctx.fillRect(0, 0, this.width, this.height);

            if (this.countdown > 0) {
                // Show countdown number
                this.ctx.fillStyle = '#ffaa00';
                this.ctx.font = 'bold 120px Arial';
                this.ctx.textAlign = 'center';
                this.ctx.shadowBlur = 20;
                this.ctx.shadowColor = '#ffaa00';
                this.ctx.fillText(this.countdown, this.width / 2, this.height / 2 + 20);

                this.ctx.fillStyle = '#ffffff';
                this.ctx.font = '24px Arial';
                this.ctx.shadowBlur = 0;
                this.ctx.fillText('Get Ready!', this.width / 2, this.height / 2 - 80);
            } else {
                // Show "FIGHT!" message
                this.ctx.fillStyle = '#ff3366';
                this.ctx.font = 'bold 80px Arial';
                this.ctx.textAlign = 'center';
                this.ctx.shadowBlur = 20;
                this.ctx.shadowColor = '#ff3366';
                this.ctx.fillText('FIGHT!', this.width / 2, this.height / 2 + 20);
            }

            this.ctx.textAlign = 'left';
            this.ctx.shadowBlur = 0;
        }
        // Draw pause screen if paused
        else if (this.paused) {
            this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
            this.ctx.fillRect(0, 0, this.width, this.height);

            this.ctx.fillStyle = '#ffaa00';
            this.ctx.font = 'bold 40px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText('PAUSED', this.width / 2, this.height / 2 - 20);

            this.ctx.fillStyle = '#ffffff';
            this.ctx.font = '20px Arial';
            this.ctx.fillText('Press SPACE to resume', this.width / 2, this.height / 2 + 30);

            this.ctx.textAlign = 'left';
        }
    }

    drawHomeScreen() {
        // Reset button areas for this screen
        this.currentButtonAreas = [];

        // Dark background
        this.ctx.fillStyle = 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)';
        this.ctx.fillRect(0, 0, this.width, this.height);

        // Gradient background
        const gradient = this.ctx.createLinearGradient(0, 0, 0, this.height);
        gradient.addColorStop(0, '#2a1a4a');
        gradient.addColorStop(0.5, '#1a1a3a');
        gradient.addColorStop(1, '#0a0a2a');
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.width, this.height);

        // Brawl Stars logo
        this.ctx.fillStyle = '#ffaa00';
        this.ctx.font = 'bold 48px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.shadowBlur = 30;
        this.ctx.shadowColor = '#ffaa00';
        this.ctx.fillText('⭐ BRAWL STARS ⭐', this.width / 2, 80);

        // Current brawler display
        this.ctx.fillStyle = '#ffffff';
        this.ctx.font = '24px Arial';
        this.ctx.shadowBlur = 0;
        this.ctx.fillText('Selected Brawler:', this.width / 2, 140);

        // Brawler icon and name
        const brawlerEmojis = {
            mortis: '🦇'
        };

        this.ctx.font = '64px Arial';
        this.ctx.fillText(brawlerEmojis[this.selectedBrawlerForBattle], this.width / 2, 200);

        this.ctx.fillStyle = '#00ff88';
        this.ctx.font = 'bold 28px Arial';
        this.ctx.fillText(this.selectedBrawlerForBattle.toUpperCase(), this.width / 2, 240);

        // Menu buttons
        this.drawHomeButton('🎮 START BATTLE', this.width / 2 - 100, 320, 200, 50, '#ff3366');

        this.ctx.textAlign = 'left';
        this.ctx.shadowBlur = 0;
    }

    drawBrawlersMenu() {
        // Reset button and brawler areas for this screen
        this.currentButtonAreas = [];
        this.currentBrawlerAreas = [];

        // Dark background
        const gradient = this.ctx.createLinearGradient(0, 0, 0, this.height);
        gradient.addColorStop(0, '#2a1a4a');
        gradient.addColorStop(1, '#1a1a3a');
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.width, this.height);

        // Title
        this.ctx.fillStyle = '#ffaa00';
        this.ctx.font = 'bold 36px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.shadowBlur = 20;
        this.ctx.shadowColor = '#ffaa00';
        this.ctx.fillText('CHOOSE YOUR BRAWLER', this.width / 2, 50);

        // Brawler grid
        const brawlers = Object.keys(this.brawlers);
        const emojis = {
            mortis: '🦇'
        };

        const cols = 3;
        const cardWidth = 120;
        const cardHeight = 100;
        const startX = (this.width - (cols * cardWidth + (cols - 1) * 20)) / 2;
        const startY = 80;

        brawlers.forEach((brawler, index) => {
            const row = Math.floor(index / cols);
            const col = index % cols;
            const x = startX + col * (cardWidth + 20);
            const y = startY + row * (cardHeight + 20);

            // Brawler card
            const isSelected = brawler === this.selectedBrawlerForBattle;
            this.ctx.fillStyle = isSelected ? '#ffaa00' : '#333366';
            this.ctx.shadowBlur = isSelected ? 20 : 0;
            this.ctx.shadowColor = '#ffaa00';
            this.ctx.fillRect(x, y, cardWidth, cardHeight);

            // Border
            this.ctx.strokeStyle = isSelected ? '#ffaa00' : '#666699';
            this.ctx.lineWidth = 3;
            this.ctx.strokeRect(x, y, cardWidth, cardHeight);

            // Emoji
            this.ctx.fillStyle = '#ffffff';
            this.ctx.font = '48px Arial';
            this.ctx.shadowBlur = 0;
            this.ctx.textAlign = 'center';
            this.ctx.fillText(emojis[brawler], x + cardWidth/2, y + 45);

            // Name
            this.ctx.font = 'bold 14px Arial';
            this.ctx.fillText(brawler.toUpperCase(), x + cardWidth/2, y + cardHeight - 10);

            // Store click area for later
            if (!this.currentBrawlerAreas) this.currentBrawlerAreas = [];
            this.currentBrawlerAreas[index] = { x, y, width: cardWidth, height: cardHeight, brawler };
        });

        // Back button
        this.drawHomeButton('← BACK', 20, this.height - 60, 100, 40, '#666666');

        this.ctx.textAlign = 'left';
        this.ctx.shadowBlur = 0;
    }

    drawBattleScreen() {
        // Same as waiting to start screen
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
        this.ctx.fillRect(0, 0, this.width, this.height);

        this.ctx.fillStyle = '#ffaa00';
        this.ctx.font = 'bold 60px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.shadowBlur = 20;
        this.ctx.shadowColor = '#ffaa00';
        this.ctx.fillText('BRAWL STARS', this.width / 2, this.height / 2 - 60);

        this.ctx.fillStyle = '#ffffff';
        this.ctx.font = '24px Arial';
        this.ctx.shadowBlur = 0;
        this.ctx.fillText(`Ready to battle with ${this.selectedBrawlerForBattle.toUpperCase()}!`, this.width / 2, this.height / 2 - 10);

        this.ctx.fillStyle = '#00ff88';
        this.ctx.font = 'bold 32px Arial';
        this.ctx.shadowBlur = 15;
        this.ctx.shadowColor = '#00ff88';
        this.ctx.fillText('🎮 CLICK START BATTLE! 🎮', this.width / 2, this.height / 2 + 40);

        this.ctx.textAlign = 'left';
        this.ctx.shadowBlur = 0;
    }

    drawHomeButton(text, x, y, width, height, color) {
        // Button background
        this.ctx.fillStyle = color;
        this.ctx.shadowBlur = 10;
        this.ctx.shadowColor = color;
        this.ctx.fillRect(x, y, width, height);

        // Button border
        this.ctx.strokeStyle = '#ffffff';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(x, y, width, height);

        // Button text
        this.ctx.fillStyle = '#ffffff';
        this.ctx.font = 'bold 18px Arial';
        this.ctx.shadowBlur = 0;
        this.ctx.textAlign = 'center';
        this.ctx.fillText(text, x + width/2, y + height/2 + 6);

        // Store click area
        if (!this.currentButtonAreas) this.currentButtonAreas = [];
        this.currentButtonAreas.push({ x, y, width, height, action: text });

        console.log(`Button "${text}" at (${x}, ${y}) size ${width}x${height}`);
    }

    drawUI() {
        // Draw minimap
        const minimapSize = 120;
        const minimapX = this.width - minimapSize - 10;
        const minimapY = 10;

        // Minimap background
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
        this.ctx.fillRect(minimapX, minimapY, minimapSize, minimapSize);

        this.ctx.strokeStyle = '#ffaa00';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(minimapX, minimapY, minimapSize, minimapSize);

        // Player position on minimap
        const playerMinimapX = minimapX + (this.player.x / this.mapWidth) * minimapSize;
        const playerMinimapY = minimapY + (this.player.y / this.mapHeight) * minimapSize;

        this.ctx.fillStyle = '#00aaff';
        this.ctx.beginPath();
        this.ctx.arc(playerMinimapX, playerMinimapY, 3, 0, Math.PI * 2);
        this.ctx.fill();

        // Camera view on minimap
        const cameraMinimapX = minimapX + (this.camera.x / this.mapWidth) * minimapSize;
        const cameraMinimapY = minimapY + (this.camera.y / this.mapHeight) * minimapSize;
        const cameraMinimapW = (this.width / this.mapWidth) * minimapSize;
        const cameraMinimapH = (this.height / this.mapHeight) * minimapSize;

        this.ctx.strokeStyle = '#ffffff';
        this.ctx.lineWidth = 1;
        this.ctx.strokeRect(cameraMinimapX, cameraMinimapY, cameraMinimapW, cameraMinimapH);

        // Draw gems on minimap
        this.ctx.fillStyle = '#00ff88';
        for (let gem of this.gems) {
            if (!gem.collected) {
                const gemMinimapX = minimapX + (gem.x / this.mapWidth) * minimapSize;
                const gemMinimapY = minimapY + (gem.y / this.mapHeight) * minimapSize;
                this.ctx.beginPath();
                this.ctx.arc(gemMinimapX, gemMinimapY, 2, 0, Math.PI * 2);
                this.ctx.fill();
            }
        }

        // Draw enemies on minimap
        this.ctx.fillStyle = '#ff3366';
        for (let enemy of this.enemies) {
            if (enemy.health > 0) {
                const enemyMinimapX = minimapX + (enemy.x / this.mapWidth) * minimapSize;
                const enemyMinimapY = minimapY + (enemy.y / this.mapHeight) * minimapSize;
                this.ctx.beginPath();
                this.ctx.arc(enemyMinimapX, enemyMinimapY, 2, 0, Math.PI * 2);
                this.ctx.fill();
            }
        }
    }

    win() {
        this.running = false;
        clearInterval(this.gameLoop);

        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
        this.ctx.fillRect(0, 0, this.width, this.height);

        this.ctx.fillStyle = '#00ff88';
        this.ctx.font = 'bold 30px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText('VICTORY!', this.width/2, this.height/2 - 20);

        this.ctx.fillStyle = '#ffaa00';
        this.ctx.font = '20px Arial';
        this.ctx.fillText(`Gems Collected: ${this.gemsCollected}`, this.width/2, this.height/2 + 20);

        this.ctx.textAlign = 'left';
    }

    gameOver() {
        this.running = false;
        clearInterval(this.gameLoop);

        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
        this.ctx.fillRect(0, 0, this.width, this.height);

        this.ctx.fillStyle = '#ff3366';
        this.ctx.font = 'bold 30px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText('GAME OVER', this.width/2, this.height/2 - 20);

        this.ctx.fillStyle = '#ffffff';
        this.ctx.font = '16px Arial';
        this.ctx.fillText('Click "Start Brawl" to try again', this.width/2, this.height/2 + 40);

        this.ctx.textAlign = 'left';
    }

    selectBrawler(brawler) {
        // Only allow brawler selection when waiting to start
        if (!this.waitingToStart) {
            console.log('Cannot change brawler during battle!');
            return;
        }

        this.player.brawler = brawler;
        console.log(`Selected brawler: ${brawler}`);

        // Update UI
        document.querySelectorAll('.brawler-card').forEach(card => {
            card.classList.remove('selected');
        });
        document.querySelector(`[data-brawler="${brawler}"]`).classList.add('selected');
    }
}

// Create global instance
const brawlInstance = new BrawlStars();


// Global functions
function startBrawlStars() {
    console.log('Start Brawl Stars clicked');
    console.log('Current game state:', brawlInstance.gameState);
    console.log('Waiting to start:', brawlInstance.waitingToStart);

    if (brawlInstance.gameState === 'battle') {
        // If on battle screen, start the countdown
        console.log('Calling startBattle()');
        brawlInstance.startBattle();
    } else if (brawlInstance.gameState === 'home') {
        // If on home screen, go to battle screen
        console.log('Calling showBattleScreen()');
        brawlInstance.showBattleScreen();
    } else {
        // If no game running, initialize new game
        console.log('Calling start()');
        brawlInstance.start();
    }
}

function resetBrawlStars() {
    console.log('Pausing Brawl Stars...');

    if (brawlInstance.running || brawlInstance.countdownActive) {
        // Just toggle pause instead of full reset
        brawlInstance.paused = !brawlInstance.paused;
        console.log(brawlInstance.paused ? 'Game paused' : 'Game resumed');
    } else {
        // If game isn't running, start it
        brawlInstance.start();
    }
}

function toggleBrawlFullscreen() {
    const canvas = document.getElementById('brawlGame');
    if (!document.fullscreenElement) {
        canvas.requestFullscreen().then(() => {
            canvas.style.width = '100vw';
            canvas.style.height = '100vh';
            canvas.style.objectFit = 'contain';
        }).catch(err => {
            console.log('Fullscreen failed:', err);
        });
    } else {
        document.exitFullscreen().then(() => {
            canvas.style.width = '';
            canvas.style.height = '';
            canvas.style.objectFit = 'initial';
        });
    }
}

// Setup game and brawler selection when page loads
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, starting Brawl Stars game...');
    // Initialize the game
    brawlInstance.start();

    // Setup brawler selection for old HTML elements (if any)
    document.querySelectorAll('.brawler-card').forEach(card => {
        card.addEventListener('click', () => {
            const brawler = card.dataset.brawler;
            brawlInstance.selectBrawler(brawler);
        });
    });
});

console.log('Brawl Stars game loaded successfully');