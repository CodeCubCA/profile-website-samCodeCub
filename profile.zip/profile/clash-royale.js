// Clash Royale Tower Defense Game
class ClashRoyale {
    constructor() {
        this.canvas = null;
        this.ctx = null;
        this.running = false;
        this.gameLoop = null;

        // Game state
        this.elixir = 10;
        this.maxElixir = 10;
        this.selectedCard = null;
        this.playerScore = 0;
        this.enemyScore = 0;

        // Game objects
        this.units = [];
        this.buildings = [];
        this.projectiles = [];
        this.particles = [];
        this.aiUnits = [];

        // Game timing
        this.lastElixirTime = 0;
        this.lastAiActionTime = 0;
        this.gameStartTime = 0;

        // Game dimensions
        this.canvasWidth = 600;
        this.canvasHeight = 400;

        // Message system
        this.messages = [];
        this.bridgeY = 200;

        // Unit definitions
        this.unitTypes = {
            knight: {
                cost: 3,
                health: 100,
                damage: 25,
                speed: 1.5,
                range: 30,
                size: 15,
                color: '#4A90E2',
                emoji: '🛡️',
                attackSpeed: 1000
            },
            archer: {
                cost: 3,
                health: 60,
                damage: 20,
                speed: 2,
                range: 80,
                size: 12,
                color: '#10B981',
                emoji: '🏹',
                attackSpeed: 800
            },
            giant: {
                cost: 5,
                health: 300,
                damage: 40,
                speed: 1,
                range: 25,
                size: 25,
                color: '#8B5CF6',
                emoji: '🗿',
                attackSpeed: 1500
            },
            wizard: {
                cost: 5,
                health: 80,
                damage: 35,
                speed: 1.8,
                range: 100,
                size: 14,
                color: '#F59E0B',
                emoji: '🧙',
                attackSpeed: 1200
            }
        };

        // Initialize towers
        this.playerTower = {
            x: 300,
            y: 350,
            health: 300,
            maxHealth: 300,
            size: 40,
            range: 120
        };

        this.enemyTower = {
            x: 300,
            y: 50,
            health: 300,
            maxHealth: 300,
            size: 40,
            range: 120
        };

        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // Card selection with improved touch handling
        document.addEventListener('click', (e) => {
            if (e.target.closest('.card')) {
                e.preventDefault();
                this.selectCard(e.target.closest('.card'));
            }
        });

        // Touch support for mobile
        document.addEventListener('touchend', (e) => {
            if (e.target.closest('.card')) {
                e.preventDefault();
                this.selectCard(e.target.closest('.card'));
            }
        });

        // Prevent default touch behaviors on cards
        document.addEventListener('touchstart', (e) => {
            if (e.target.closest('.card')) {
                e.preventDefault();
            }
        });
    }

    start() {
        console.log('Starting Clash Royale...');
        this.canvas = document.getElementById('clashGame');
        if (!this.canvas) {
            console.error('Canvas not found!');
            return;
        }

        // Set canvas dimensions properly
        this.canvas.width = this.canvasWidth;
        this.canvas.height = this.canvasHeight;

        this.ctx = this.canvas.getContext('2d');
        this.running = true;
        this.gameStartTime = Date.now();

        // Reset game state
        this.elixir = 10;
        this.selectedCard = null;
        this.playerScore = 0;
        this.enemyScore = 0;
        this.units = [];
        this.aiUnits = [];
        this.projectiles = [];
        this.particles = [];

        // Reset tower health
        this.playerTower.health = this.playerTower.maxHealth;
        this.enemyTower.health = this.enemyTower.maxHealth;

        // Remove existing event listeners to prevent duplicates
        this.canvas.removeEventListener('click', this.handleCanvasClick);
        this.canvas.removeEventListener('touchend', this.handleCanvasTouch);

        // Add canvas click handler for unit deployment
        this.handleCanvasClick = this.handleCanvasClick.bind(this);
        this.handleCanvasTouch = this.handleCanvasTouch.bind(this);

        this.canvas.addEventListener('click', this.handleCanvasClick);
        this.canvas.addEventListener('touchend', this.handleCanvasTouch);

        // Prevent default touch behaviors on canvas
        this.canvas.addEventListener('touchstart', (e) => e.preventDefault());
        this.canvas.addEventListener('touchmove', (e) => e.preventDefault());

        // Start game loop
        if (this.gameLoop) {
            clearInterval(this.gameLoop);
        }
        this.gameLoop = setInterval(() => this.update(), 16); // 60 FPS

        this.updateUI();
        console.log('Game started successfully!');
    }

    selectCard(cardElement) {
        const cardType = cardElement.dataset.type;
        const cost = parseInt(cardElement.dataset.cost);

        // Check if card is disabled
        if (cardElement.classList.contains('disabled')) {
            this.showMessage('Not enough elixir!', '#FF6B6B');
            return;
        }

        // Check if player has enough elixir
        if (this.elixir < cost) {
            this.showMessage('Not enough elixir!', '#FF6B6B');
            return;
        }

        // If same card is already selected, deselect it
        if (this.selectedCard === cardType) {
            cardElement.classList.remove('selected');
            this.selectedCard = null;
            this.showMessage('Card deselected', '#FFA500');
            return;
        }

        // Remove previous selection
        document.querySelectorAll('.card').forEach(card => {
            card.classList.remove('selected');
        });

        // Select new card
        cardElement.classList.add('selected');
        this.selectedCard = cardType;
        const unitType = this.unitTypes[cardType];
        this.showMessage(`${unitType.emoji} ${cardType.charAt(0).toUpperCase() + cardType.slice(1)} selected!`, '#10B981');
    }

    handleCanvasClick(e) {
        this.deployUnit(e);
    }

    handleCanvasTouch(e) {
        e.preventDefault();
        const touch = e.changedTouches ? e.changedTouches[0] : e.touches[0];
        if (touch) {
            const event = {
                clientX: touch.clientX,
                clientY: touch.clientY
            };
            this.deployUnit(event);
        }
    }

    deployUnit(e) {
        if (!this.selectedCard || !this.running) return;

        const rect = this.canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) * (this.canvasWidth / rect.width);
        const y = (e.clientY - rect.top) * (this.canvasHeight / rect.height);

        // Only allow deployment in player's half (below bridge + buffer)
        if (y < this.bridgeY + 30) {
            this.showMessage('Cannot deploy in enemy territory!', '#FF6B6B');
            return;
        }

        const unitType = this.unitTypes[this.selectedCard];
        if (!unitType) return;

        // Double check elixir
        if (this.elixir < unitType.cost) {
            this.showMessage('Not enough elixir!', '#FF6B6B');
            return;
        }

        // Check for unit overlap
        const tooClose = this.units.some(unit => {
            return this.getDistance({ x, y }, unit) < unit.size + 20;
        });

        if (tooClose) {
            this.showMessage('Too close to another unit!', '#FF6B6B');
            return;
        }

        // Spend elixir
        this.elixir -= unitType.cost;

        // Create unit
        const unit = {
            ...unitType,
            x: x,
            y: y,
            maxHealth: unitType.health,
            id: Date.now() + Math.random(),
            side: 'player',
            target: null,
            lastAttackTime: 0,
            direction: { x: 0, y: -1 } // Move toward enemy
        };

        this.units.push(unit);
        this.createParticles(x, y, unitType.color, 8);

        // Clear selection
        this.selectedCard = null;
        document.querySelectorAll('.card').forEach(card => {
            card.classList.remove('selected');
        });

        this.updateUI();
        this.showMessage(`${unitType.emoji} deployed!`, unitType.color);
    }

    update() {
        if (!this.running) return;

        // Update elixir
        this.updateElixir();

        // Update units
        this.updateUnits();
        this.updateAiUnits();

        // Update projectiles
        this.updateProjectiles();

        // Update particles
        this.updateParticles();

        // Update messages
        this.updateMessages();

        // AI behavior
        this.updateAI();

        // Check win conditions
        this.checkWinConditions();

        // Draw everything
        this.draw();

        // Update UI
        this.updateUI();
    }

    updateElixir() {
        const now = Date.now();
        if (now - this.lastElixirTime > 2000) { // Gain 1 elixir every 2 seconds
            if (this.elixir < this.maxElixir) {
                this.elixir++;
                this.lastElixirTime = now;
            }
        }
    }

    updateUnits() {
        for (let i = this.units.length - 1; i >= 0; i--) {
            const unit = this.units[i];

            // Find nearest target
            this.findTarget(unit);

            // Move toward target or enemy tower
            if (unit.target && unit.target.health > 0) {
                this.moveTowardTarget(unit, unit.target);
                if (this.getDistance(unit, unit.target) <= unit.range) {
                    this.tryAttack(unit, unit.target);
                }
            } else {
                // Move toward enemy tower
                this.moveTowardTarget(unit, this.enemyTower);
                if (this.getDistance(unit, this.enemyTower) <= unit.range) {
                    this.tryAttack(unit, this.enemyTower);
                }
            }

            // Keep units within canvas bounds
            unit.x = Math.max(unit.size, Math.min(this.canvasWidth - unit.size, unit.x));
            unit.y = Math.max(unit.size, Math.min(this.canvasHeight - unit.size, unit.y));

            // Remove dead units
            if (unit.health <= 0) {
                this.createParticles(unit.x, unit.y, '#FF6B6B', 12);
                this.units.splice(i, 1);
            }
        }
    }

    updateAiUnits() {
        for (let i = this.aiUnits.length - 1; i >= 0; i--) {
            const unit = this.aiUnits[i];

            // Find nearest player unit or tower
            let target = this.findNearestPlayerUnit(unit);
            if (!target || target.health <= 0) {
                target = this.playerTower;
            }

            // Move toward target
            this.moveTowardTarget(unit, target);

            // Attack if in range
            if (this.getDistance(unit, target) <= unit.range) {
                this.tryAttack(unit, target);
            }

            // Keep units within canvas bounds
            unit.x = Math.max(unit.size, Math.min(this.canvasWidth - unit.size, unit.x));
            unit.y = Math.max(unit.size, Math.min(this.canvasHeight - unit.size, unit.y));

            // Remove dead units
            if (unit.health <= 0) {
                this.createParticles(unit.x, unit.y, '#FF6B6B', 12);
                this.aiUnits.splice(i, 1);
            }
        }
    }

    updateProjectiles() {
        for (let i = this.projectiles.length - 1; i >= 0; i--) {
            const proj = this.projectiles[i];

            proj.x += proj.dx;
            proj.y += proj.dy;
            proj.life--;

            let hit = false;

            // Check collisions
            if (proj.side === 'player') {
                // Check AI unit collisions
                for (let j = 0; j < this.aiUnits.length; j++) {
                    const unit = this.aiUnits[j];
                    if (unit.health > 0 && this.getDistance(proj, unit) < unit.size) {
                        unit.health -= proj.damage;
                        this.createParticles(proj.x, proj.y, '#FFD700', 6);
                        hit = true;
                        break;
                    }
                }

                // Check enemy tower collision
                if (!hit && this.getDistance(proj, this.enemyTower) < this.enemyTower.size) {
                    this.enemyTower.health -= proj.damage;
                    this.createParticles(proj.x, proj.y, '#FFD700', 6);
                    hit = true;
                }
            } else {
                // Check player unit collisions
                for (let j = 0; j < this.units.length; j++) {
                    const unit = this.units[j];
                    if (unit.health > 0 && this.getDistance(proj, unit) < unit.size) {
                        unit.health -= proj.damage;
                        this.createParticles(proj.x, proj.y, '#FFD700', 6);
                        hit = true;
                        break;
                    }
                }

                // Check player tower collision
                if (!hit && this.getDistance(proj, this.playerTower) < this.playerTower.size) {
                    this.playerTower.health -= proj.damage;
                    this.createParticles(proj.x, proj.y, '#FFD700', 6);
                    hit = true;
                }
            }

            // Remove hit or expired projectiles
            if (hit || proj.life <= 0 || proj.x < 0 || proj.x > this.canvasWidth ||
                proj.y < 0 || proj.y > this.canvasHeight) {
                this.projectiles.splice(i, 1);
            }
        }
    }

    updateParticles() {
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const particle = this.particles[i];

            particle.x += particle.dx;
            particle.y += particle.dy;
            particle.life--;
            particle.dx *= 0.98;
            particle.dy *= 0.98;

            if (particle.life <= 0) {
                this.particles.splice(i, 1);
            }
        }
    }

    updateMessages() {
        for (let i = this.messages.length - 1; i >= 0; i--) {
            const message = this.messages[i];
            message.life--;
            message.y -= 0.5; // Float upward

            if (message.life <= 0) {
                this.messages.splice(i, 1);
            }
        }
    }

    updateAI() {
        const now = Date.now();
        const aiDelay = 2000 + Math.random() * 3000; // AI acts every 2-5 seconds

        if (now - this.lastAiActionTime > aiDelay) {
            this.performAIAction();
            this.lastAiActionTime = now;
        }
    }

    performAIAction() {
        // Smart AI: consider player threats and choose appropriate units
        const unitTypeNames = Object.keys(this.unitTypes);
        let selectedUnit = 'knight'; // Default

        // Simple strategy: if player has many units, spawn stronger units
        if (this.units.length > 3) {
            selectedUnit = Math.random() > 0.5 ? 'giant' : 'wizard';
        } else if (this.units.length > 1) {
            selectedUnit = Math.random() > 0.5 ? 'archer' : 'knight';
        } else {
            selectedUnit = unitTypeNames[Math.floor(Math.random() * unitTypeNames.length)];
        }

        const unitType = this.unitTypes[selectedUnit];

        // Spawn in enemy territory (top half)
        const x = 100 + Math.random() * 400;
        const y = 50 + Math.random() * (this.bridgeY - 100);

        const unit = {
            ...unitType,
            x: x,
            y: y,
            maxHealth: unitType.health,
            id: Date.now() + Math.random(),
            side: 'ai',
            target: null,
            lastAttackTime: 0,
            direction: { x: 0, y: 1 } // Move toward player
        };

        this.aiUnits.push(unit);
        this.createParticles(x, y, unitType.color, 8);

        // Show AI action message
        this.showMessage(`AI deployed ${unitType.emoji}!`, '#EF4444');
    }

    findTarget(unit) {
        let nearestDistance = Infinity;
        let nearestTarget = null;

        // Check AI units for player units
        for (const aiUnit of this.aiUnits) {
            if (aiUnit.health <= 0) continue;
            const distance = this.getDistance(unit, aiUnit);
            if (distance < nearestDistance && distance <= unit.range * 1.5) {
                nearestDistance = distance;
                nearestTarget = aiUnit;
            }
        }

        unit.target = nearestTarget;
    }

    findNearestPlayerUnit(aiUnit) {
        let nearestDistance = Infinity;
        let nearestTarget = null;

        for (const unit of this.units) {
            if (unit.health <= 0) continue;
            const distance = this.getDistance(aiUnit, unit);
            if (distance < nearestDistance && distance <= aiUnit.range * 1.5) {
                nearestDistance = distance;
                nearestTarget = unit;
            }
        }

        return nearestTarget;
    }

    moveTowardTarget(unit, target) {
        const dx = target.x - unit.x;
        const dy = target.y - unit.y;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance > unit.range) {
            const moveX = (dx / distance) * unit.speed;
            const moveY = (dy / distance) * unit.speed;

            unit.x += moveX;
            unit.y += moveY;
        }
    }

    tryAttack(attacker, target) {
        const now = Date.now();
        if (now - attacker.lastAttackTime > attacker.attackSpeed) {
            // Ranged attack (archer, wizard)
            if (attacker.range > 50) {
                this.createProjectile(attacker, target);
            } else {
                // Melee attack
                target.health -= attacker.damage;
                this.createParticles(target.x, target.y, '#FFD700', 8);
            }

            attacker.lastAttackTime = now;
        }
    }

    createProjectile(from, to) {
        const dx = to.x - from.x;
        const dy = to.y - from.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const speed = 4;

        this.projectiles.push({
            x: from.x,
            y: from.y,
            dx: (dx / distance) * speed,
            dy: (dy / distance) * speed,
            damage: from.damage,
            life: 100,
            side: from.side,
            color: from.color
        });
    }

    createParticles(x, y, color, count) {
        for (let i = 0; i < count; i++) {
            this.particles.push({
                x: x,
                y: y,
                dx: (Math.random() - 0.5) * 6,
                dy: (Math.random() - 0.5) * 6,
                life: 30,
                color: color
            });
        }
    }

    getDistance(obj1, obj2) {
        const dx = obj1.x - obj2.x;
        const dy = obj1.y - obj2.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    checkWinConditions() {
        if (this.playerTower.health <= 0) {
            this.enemyScore++;
            this.gameOver('💀 Enemy Destroyed Your Tower!', '#EF4444');
        } else if (this.enemyTower.health <= 0) {
            this.playerScore++;
            this.gameOver('🏆 Victory! Tower Destroyed!', '#10B981');
        }

        // Optional: Time-based victory (3 minutes)
        const gameTime = Date.now() - this.gameStartTime;
        if (gameTime > 180000) { // 3 minutes
            if (this.playerTower.health > this.enemyTower.health) {
                this.playerScore++;
                this.gameOver('⏰ Time Up! You Win!', '#10B981');
            } else if (this.enemyTower.health > this.playerTower.health) {
                this.enemyScore++;
                this.gameOver('⏰ Time Up! Enemy Wins!', '#EF4444');
            } else {
                this.gameOver('⏰ Time Up! Draw!', '#FFA500');
            }
        }
    }

    gameOver(message, color = '#FFD700') {
        this.running = false;
        if (this.gameLoop) {
            clearInterval(this.gameLoop);
        }

        // Clear all units and effects
        this.units = [];
        this.aiUnits = [];
        this.projectiles = [];
        this.selectedCard = null;

        // Clear card selections
        document.querySelectorAll('.card').forEach(card => {
            card.classList.remove('selected');
        });

        // Draw final game state first
        this.draw();

        // Draw game over overlay
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
        this.ctx.fillRect(0, 0, this.canvasWidth, this.canvasHeight);

        this.ctx.fillStyle = color;
        this.ctx.font = 'bold 32px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.strokeStyle = '#000';
        this.ctx.lineWidth = 3;
        this.ctx.strokeText(message, this.canvasWidth / 2, this.canvasHeight / 2 - 20);
        this.ctx.fillText(message, this.canvasWidth / 2, this.canvasHeight / 2 - 20);

        // Show score
        this.ctx.fillStyle = '#FFF';
        this.ctx.font = '20px Arial';
        this.ctx.fillText(`Score: You ${this.playerScore} - ${this.enemyScore} Enemy`, this.canvasWidth / 2, this.canvasHeight / 2 + 20);

        this.ctx.fillStyle = '#FFD700';
        this.ctx.font = '18px Arial';
        this.ctx.fillText('Click "Start Battle" to play again', this.canvasWidth / 2, this.canvasHeight / 2 + 60);

        this.ctx.textAlign = 'left';

        this.updateUI();
    }

    draw() {
        // Clear canvas with gradient background
        const gradient = this.ctx.createLinearGradient(0, 0, 0, this.canvasHeight);
        gradient.addColorStop(0, '#87CEEB'); // Sky
        gradient.addColorStop(0.5, '#228B22'); // Grass
        gradient.addColorStop(1, '#8B4513'); // Ground
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.canvasWidth, this.canvasHeight);

        // Draw bridge/river
        this.ctx.fillStyle = '#4682B4';
        this.ctx.fillRect(0, this.bridgeY - 10, this.canvasWidth, 20);

        // Draw bridge
        this.ctx.fillStyle = '#8B4513';
        this.ctx.fillRect(250, this.bridgeY - 15, 100, 30);

        // Draw towers
        this.drawTower(this.playerTower, '#4A90E2', '🏰');
        this.drawTower(this.enemyTower, '#EF4444', '🏰');

        // Draw units
        this.units.forEach(unit => this.drawUnit(unit));
        this.aiUnits.forEach(unit => this.drawUnit(unit));

        // Draw projectiles
        this.projectiles.forEach(proj => this.drawProjectile(proj));

        // Draw particles
        this.particles.forEach(particle => this.drawParticle(particle));

        // Draw messages
        this.drawMessages();
    }

    drawTower(tower, color, emoji) {
        // Tower shadow
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
        this.ctx.beginPath();
        this.ctx.arc(tower.x + 3, tower.y + 3, tower.size, 0, Math.PI * 2);
        this.ctx.fill();

        // Tower body
        this.ctx.fillStyle = color;
        this.ctx.beginPath();
        this.ctx.arc(tower.x, tower.y, tower.size, 0, Math.PI * 2);
        this.ctx.fill();

        // Tower emoji
        this.ctx.font = '32px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(emoji, tower.x, tower.y + 10);

        // Health bar
        const healthPercent = tower.health / tower.maxHealth;
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
        this.ctx.fillRect(tower.x - 30, tower.y - tower.size - 15, 60, 8);
        this.ctx.fillStyle = healthPercent > 0.5 ? '#10B981' : healthPercent > 0.25 ? '#F59E0B' : '#EF4444';
        this.ctx.fillRect(tower.x - 28, tower.y - tower.size - 13, 56 * healthPercent, 4);

        this.ctx.textAlign = 'left';
    }

    drawMessages() {
        this.ctx.font = 'bold 18px Arial';
        this.ctx.textAlign = 'center';

        for (let i = 0; i < this.messages.length; i++) {
            const message = this.messages[i];
            const alpha = message.life / 120;

            this.ctx.save();
            this.ctx.globalAlpha = alpha;
            this.ctx.fillStyle = message.color;
            this.ctx.strokeStyle = '#000';
            this.ctx.lineWidth = 2;

            const y = message.y + (i * 25);
            this.ctx.strokeText(message.text, this.canvasWidth / 2, y);
            this.ctx.fillText(message.text, this.canvasWidth / 2, y);

            this.ctx.restore();
        }

        this.ctx.textAlign = 'left';
    }

    drawUnit(unit) {
        // Unit shadow
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
        this.ctx.beginPath();
        this.ctx.arc(unit.x + 2, unit.y + 2, unit.size, 0, Math.PI * 2);
        this.ctx.fill();

        // Unit body
        this.ctx.fillStyle = unit.color;
        this.ctx.beginPath();
        this.ctx.arc(unit.x, unit.y, unit.size, 0, Math.PI * 2);
        this.ctx.fill();

        // Unit emoji
        this.ctx.font = `${unit.size + 8}px Arial`;
        this.ctx.textAlign = 'center';
        this.ctx.fillText(unit.emoji, unit.x, unit.y + 5);

        // Health bar
        const healthPercent = unit.health / unit.maxHealth;
        if (healthPercent < 1) {
            this.ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
            this.ctx.fillRect(unit.x - 15, unit.y - unit.size - 10, 30, 4);
            this.ctx.fillStyle = healthPercent > 0.5 ? '#10B981' : healthPercent > 0.25 ? '#F59E0B' : '#EF4444';
            this.ctx.fillRect(unit.x - 14, unit.y - unit.size - 9, 28 * healthPercent, 2);
        }

        this.ctx.textAlign = 'left';
    }

    drawProjectile(proj) {
        this.ctx.fillStyle = proj.color;
        this.ctx.beginPath();
        this.ctx.arc(proj.x, proj.y, 3, 0, Math.PI * 2);
        this.ctx.fill();

        // Trail effect
        this.ctx.strokeStyle = proj.color;
        this.ctx.lineWidth = 2;
        this.ctx.beginPath();
        this.ctx.moveTo(proj.x - proj.dx * 3, proj.y - proj.dy * 3);
        this.ctx.lineTo(proj.x, proj.y);
        this.ctx.stroke();
    }

    drawParticle(particle) {
        this.ctx.save();
        this.ctx.globalAlpha = particle.life / 30;
        this.ctx.fillStyle = particle.color;
        this.ctx.beginPath();
        this.ctx.arc(particle.x, particle.y, 2, 0, Math.PI * 2);
        this.ctx.fill();
        this.ctx.restore();
    }

    updateUI() {
        // Update elixir bar
        const elixirFill = document.querySelector('.elixir-fill');
        const elixirCount = document.querySelector('.elixir-count');

        if (elixirFill && elixirCount) {
            const elixirPercent = (this.elixir / this.maxElixir) * 100;
            elixirFill.style.width = `${elixirPercent}%`;
            elixirCount.textContent = this.elixir;
        }

        // Update card availability
        document.querySelectorAll('.card').forEach(card => {
            const cost = parseInt(card.dataset.cost);
            if (this.elixir < cost) {
                card.classList.add('disabled');
            } else {
                card.classList.remove('disabled');
            }
        });
    }

    showMessage(text, color = '#FFD700') {
        // Add message to array for display
        this.messages.push({
            text: text,
            color: color,
            life: 120, // 2 seconds at 60 FPS
            y: 50
        });

        // Keep only last 3 messages
        if (this.messages.length > 3) {
            this.messages.shift();
        }

        console.log(text);
    }

    reset() {
        this.running = false;
        if (this.gameLoop) {
            clearInterval(this.gameLoop);
        }

        // Initialize canvas and context if not already done
        if (!this.canvas) {
            this.canvas = document.getElementById('clashGame');
        }
        if (!this.ctx && this.canvas) {
            this.ctx = this.canvas.getContext('2d');
        }

        if (!this.ctx) {
            console.error('Unable to get canvas context');
            return;
        }

        // Clear canvas
        const gradient = this.ctx.createLinearGradient(0, 0, 0, this.canvasHeight);
        gradient.addColorStop(0, '#87CEEB');
        gradient.addColorStop(0.5, '#228B22');
        gradient.addColorStop(1, '#8B4513');
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.canvasWidth, this.canvasHeight);

        // Draw bridge
        this.ctx.fillStyle = '#4682B4';
        this.ctx.fillRect(0, this.bridgeY - 10, this.canvasWidth, 20);
        this.ctx.fillStyle = '#8B4513';
        this.ctx.fillRect(250, this.bridgeY - 15, 100, 30);

        // Reset towers
        this.playerTower.health = this.playerTower.maxHealth;
        this.enemyTower.health = this.enemyTower.maxHealth;
        this.drawTower(this.playerTower, '#4A90E2', '🏰');
        this.drawTower(this.enemyTower, '#EF4444', '🏰');

        // Welcome message
        this.ctx.fillStyle = '#FFD700';
        this.ctx.font = 'bold 28px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText('⚔️ Royal Tower Defense', this.canvasWidth / 2, 150);

        this.ctx.fillStyle = '#FFF';
        this.ctx.font = '18px Arial';
        this.ctx.fillText('Select a card and click to deploy units!', this.canvasWidth / 2, 180);
        this.ctx.fillText('Destroy the enemy tower to win!', this.canvasWidth / 2, 210);

        this.ctx.textAlign = 'left';

        // Reset game state
        this.elixir = 10;
        this.selectedCard = null;
        this.playerScore = 0;
        this.enemyScore = 0;
        this.units = [];
        this.aiUnits = [];
        this.projectiles = [];
        this.particles = [];
        this.messages = [];

        // Reset timing
        this.lastElixirTime = Date.now();
        this.lastAiActionTime = Date.now();
        this.gameStartTime = Date.now();

        // Clear card selections
        document.querySelectorAll('.card').forEach(card => {
            card.classList.remove('selected', 'disabled');
        });

        this.updateUI();
    }
}

// Create global instance
const clashGame = new ClashRoyale();

// Global functions for buttons
function startClashRoyale() {
    console.log('Starting Clash Royale...');
    clashGame.start();
}

function resetClashRoyale() {
    console.log('Resetting Clash Royale...');
    clashGame.reset();
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing Clash Royale...');

    function initializeGame() {
        const canvas = document.getElementById('clashGame');
        if (canvas) {
            console.log('Canvas found, initializing game...');
            clashGame.reset();
        } else {
            console.log('Canvas not found yet, retrying...');
            setTimeout(initializeGame, 500);
        }
    }

    setTimeout(initializeGame, 300);
});

console.log('Clash Royale game script loaded successfully');